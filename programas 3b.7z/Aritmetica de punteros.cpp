#include <iostream>
int main() {
    int arreglo[] = {1, 2, 3, 4, 5};
    int *ptrArreglo = arreglo; // El nombre del array es la direcci�n del primer elemento

    std::cout << "Primer elemento: " << *ptrArreglo << std::endl;
    std::cout << "Segundo elemento: " << *(ptrArreglo + 1) << std::endl;
    std::cout << "Tercer elemento: " << *(ptrArreglo + 2) << std::endl;

    // Tambi�n se puede iterar con punteros:
    for (int i = 0; i < 5; ++i) {
        std::cout << "Elemento " << i << ": " << *(ptrArreglo + i) << std::endl;
    }
    return 0;
}
