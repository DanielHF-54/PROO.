#include <iostream>
int main() {
	int*ptr = 0; // inicializacion con un puntero nulo
	
	if (ptr== 0) {
		std::cout << "El puntero es nulo." << std::endl;
	}else {
		std::cout << "El valor apuntado por el puntero es:" << *ptr << std::endl;
	}
	
	return 0;
}
